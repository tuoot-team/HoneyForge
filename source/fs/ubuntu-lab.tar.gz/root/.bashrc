# ~/.bashrc
